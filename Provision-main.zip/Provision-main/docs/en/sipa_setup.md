# Set-up Sideload IPA

- Get the Apple Music APK and extract it somewhere

> You can download only the slice for your architecture, we don't need everything else

- Move the lib/ folder next to the executable


- \(Optional) remove in lib/ the folders that does not designate your architecture and 
delete everything in the remaining folder except *libstoreservicescore.so* and *libCoreADI.so* to
save space
