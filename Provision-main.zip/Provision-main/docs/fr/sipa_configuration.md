# Configurer Sideload IPA

- Téléchargez l'APK d'Apple Music, et extrayez-le quelque part.

> Vous pouvez ne télécharger que la tranche correspondante à votre architecture, nous n'utiliserons 
de toute façon que peu de fichiers.

- Déplacez le dossier lib/ à côté de l'exécutable


- \(Optionnel) supprimez dans le dossier lib/ tous ceux qui ne désigne pas votre architecture, et
supprimez tout dans le dossier qui reste sauf *libstoreservicescore.so* et *libCoreADI.so* pour
économiser de la place
